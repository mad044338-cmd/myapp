
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
import json
import os
import time
import threading

# ----------------- تخزين البيانات -----------------
DATA_FILE = "bot_data.json"

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"accounts": [], "comments": [], "settings": {"daily_limit": 70, "proxy": "", "vpn": False}}

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# ----------------- الشاشات -----------------
class AccountsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = BoxLayout(orientation="vertical")
        self.add_widget(self.layout)
        self.refresh()

    def refresh(self):
        self.layout.clear_widgets()
        data = load_data()
        for acc in data["accounts"]:
            self.layout.add_widget(Label(text=acc["username"]))
        add_btn = Button(text="➕ إضافة حساب")
        add_btn.bind(on_release=self.add_account)
        self.layout.add_widget(add_btn)

    def add_account(self, *args):
        layout = BoxLayout(orientation="vertical")
        username = TextInput(hint_text="اسم المستخدم")
        password = TextInput(hint_text="كلمة المرور", password=True)
        save_btn = Button(text="حفظ")
        layout.add_widget(username)
        layout.add_widget(password)
        layout.add_widget(save_btn)
        self.layout.clear_widgets()
        self.layout.add_widget(layout)

        def save_acc(*a):
            data = load_data()
            data["accounts"].append({"username": username.text, "password": password.text})
            save_data(data)
            self.refresh()
        save_btn.bind(on_release=save_acc)

class CommentsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = BoxLayout(orientation="vertical")
        self.add_widget(self.layout)
        self.refresh()

    def refresh(self):
        self.layout.clear_widgets()
        data = load_data()
        for c in data["comments"]:
            self.layout.add_widget(Label(text=c))
        add_btn = Button(text="➕ إضافة تعليق")
        add_btn.bind(on_release=self.add_comment)
        self.layout.add_widget(add_btn)

    def add_comment(self, *args):
        layout = BoxLayout(orientation="vertical")
        txt = TextInput(hint_text="اكتب تعليقك هنا")
        save_btn = Button(text="حفظ")
        layout.add_widget(txt)
        layout.add_widget(save_btn)
        self.layout.clear_widgets()
        self.layout.add_widget(layout)

        def save_c(*a):
            data = load_data()
            data["comments"].append(txt.text)
            save_data(data)
            self.refresh()
        save_btn.bind(on_release=save_c)

class SettingsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = BoxLayout(orientation="vertical")
        self.add_widget(self.layout)
        self.refresh()

    def refresh(self):
        self.layout.clear_widgets()
        data = load_data()
        daily = TextInput(text=str(data["settings"]["daily_limit"]), hint_text="عدد التعليقات باليوم")
        proxy = TextInput(text=data["settings"]["proxy"], hint_text="بروكسي (اختياري)")
        save_btn = Button(text="💾 حفظ الإعدادات")
        self.layout.add_widget(Label(text="الإعدادات"))
        self.layout.add_widget(daily)
        self.layout.add_widget(proxy)
        self.layout.add_widget(save_btn)

        def save_s(*a):
            data["settings"]["daily_limit"] = int(daily.text)
            data["settings"]["proxy"] = proxy.text
            save_data(data)
            self.refresh()
        save_btn.bind(on_release=save_s)

class ControlScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = BoxLayout(orientation="vertical")
        self.status = Label(text="⏹️ البوت متوقف")
        start_btn = Button(text="▶️ تشغيل البوت")
        stop_btn = Button(text="⏹️ إيقاف البوت")

        start_btn.bind(on_release=self.start_bot)
        stop_btn.bind(on_release=self.stop_bot)

        self.layout.add_widget(self.status)
        self.layout.add_widget(start_btn)
        self.layout.add_widget(stop_btn)
        self.add_widget(self.layout)
        self.running = False

    def start_bot(self, *args):
        if self.running:
            self.status.text = "⚡ البوت يعمل بالفعل"
            return
        self.running = True
        self.status.text = "⚡ جاري التشغيل..."
        threading.Thread(target=self.run_bot, daemon=True).start()

    def stop_bot(self, *args):
        self.running = False
        self.status.text = "⏹️ تم إيقاف البوت"

    def run_bot(self):
        data = load_data()
        comments = data["comments"]
        accounts = data["accounts"]
        limit = data["settings"]["daily_limit"]
        if not comments or not accounts:
            self.status.text = "❌ أضف حسابات وتعليقات أولا"
            return

        delay = 24 * 60 * 60 / limit  # توزيع التعليقات خلال اليوم
        i = 0
        while self.running:
            acc = accounts[i % len(accounts)]
            comment = comments[i % len(comments)]
            self.status.text = f"💬 [{acc['username']}] يعلق: {comment}"
            print(self.status.text)
            time.sleep(delay)
            i += 1

# ----------------- التطبيق -----------------
class InstaBotApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(AccountsScreen(name="accounts"))
        sm.add_widget(CommentsScreen(name="comments"))
        sm.add_widget(SettingsScreen(name="settings"))
        sm.add_widget(ControlScreen(name="control"))
        return sm

if __name__ == "__main__":
    InstaBotApp().run()
